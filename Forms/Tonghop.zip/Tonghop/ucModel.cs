﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms.Tonghop
{
    public partial class ucModel : UserControl
    {
        public delegate void SendData(string name, object sender, EventArgs e);
        public bool IsZoom = false;
        public event SendData Datatb;
        public DataTable dtJig;
        public DataTable dtTool;
        public int size;
        public string MachineName;
        public string goodCode;
        public string Knife;
        public string STD;
        public string ATC;
        public string CurrentSTD;
        public string CurrentATC;
        public string Numberproduct;
        public ucModel()
        {
            InitializeComponent();
        }
     
        private void ucModel_Load(object sender, EventArgs e)
        {
            lbGoodsCode.Text = goodCode;
            lbName.Text = MachineName;
            lbKnifeCode.Text = Knife;
            lbSTD.Text = STD;
            lbATC.Text = STD;
            lbCurrentATC.Text = CurrentATC;
            lbCurrentSTD.Text = CurrentSTD;
            lbNumberProduct.Text = Numberproduct;
            grdData.DataSource = dtJig;
            grdData1.DataSource = dtTool;
        }
        void loadData()
        {

        }
    }
}
