﻿using BMS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms.Tonghop
{
    public partial class frmProductKnife : _Forms
    {
        public frmProductKnife()
        {

            InitializeComponent();

        }

        ucModel UcModel;
        private void frmProductKnife_Load(object sender, EventArgs e)
        {
            loadStage();
        }
        DateTime dateStart;
        DateTime dateEnd;
        void convertdate()
        {
            dateStart = new DateTime(dtpDate.Value.Year, dtpDate.Value.Month, dtpDate.Value.Day, 0, 0, 0);
            dateEnd = new DateTime(dtpDate.Value.Year, dtpDate.Value.Month, dtpDate.Value.Day, 23, 59, 59);
        }
        void loadStage()
        {
            DataTable dt = TextUtils.Select($"Select StageCode,ID From Stage ");
            cbStage.DisplayMember = "StageCode";
            cbStage.ValueMember = "ID";
            cbStage.DataSource = dt;
        }
        List<ucModel> lstUc = new List<ucModel>();
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        void loadDataGrv()
        {
            tableLayoutPanel2.RowStyles.RemoveAt(2);
            tableLayoutPanel2.Visible = false;
            convertdate();
            for (int i = 0; i < lstUc.Count; i++)
            {
                tableLayoutPanel2.Controls.Remove(lstUc[i]);
                //tableLayoutPanel2.RowStyles.RemoveAt(i + 2);
            }
            lstUc.Clear();
            DataTable dt = TextUtils.Select($"Select m.* From Stage s inner join Machine m on s.ID=m.StageID where s.ID={cbStage.SelectedValue}");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string machinecode = TextUtils.ToString(dt.Rows[i]["MachineCode"]);
                //DataTable dtcode = TextUtils.Select($"Select c.OrderCode,c.GoodsCode,c.KnifeDetailCode,c.Type From CheckHistory c Inner join Machine m on m.MachineCode=c.Machine where m.MachineCode = '{machinecode}'");
                DataSet ds = TextUtils.LoadDataSetFromSP("spGetDisplayAndon", new string[] { "@Machine", "@dateStart", "@dateEnd" }, new object[] { machinecode, dateStart, dateEnd });
                UcModel = new ucModel();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    UcModel.goodCode = TextUtils.ToString(ds.Tables[0].Rows[0]["GoodsCode"]);
                    UcModel.STD = TextUtils.ToString(ds.Tables[0].Rows[0]["STD"]);
                    UcModel.ATC = TextUtils.ToString(ds.Tables[0].Rows[0]["ATC"]);
                    UcModel.CurrentATC = TextUtils.ToString(ds.Tables[0].Rows[0]["CurrentATC"]);
                    UcModel.CurrentSTD = TextUtils.ToString(ds.Tables[0].Rows[0]["CurrentSTD"]);
                    UcModel.Knife = TextUtils.ToString(ds.Tables[0].Rows[0]["KnifeCode"]);
                   // UcModel.Numberproduct = TextUtils.ToString(ds.Tables[2].Rows[0]["NumberProduct"]);
                }
                UcModel.Dock = DockStyle.Fill;
                UcModel.dtJig = ds.Tables[1];
                UcModel.dtTool = ds.Tables[2];
                UcModel.MachineName = machinecode;
                lstUc.Add(UcModel);
                tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25f));
                tableLayoutPanel2.Controls.Add(UcModel, 0, i + 2);
                tableLayoutPanel2.SetColumnSpan(UcModel, 10);
            }
            
             tableLayoutPanel2.Visible = true;
        }
        private async void loadUC(DataTable dt,int i)
        {
            Task task = Task.Factory.StartNew(() =>
            {
                if (this.InvokeRequired)
                    tableLayoutPanel2.Invoke(new Action(() => {  }));
                else tableLayoutPanel2.Controls.Add(UcModel, 0, i + 2);
                if (this.InvokeRequired)
                    tableLayoutPanel2.Invoke(new Action(() => {  }));
                else tableLayoutPanel2.SetColumnSpan(UcModel, 10);
            });
            await task;
        }
        private void cbStage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                loadDataGrv();
            }
        }


        private void dtpDate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                loadDataGrv();
            }
        }

    }
}
